
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {ConnexionComponent} from './connexion/connexion.component';
import {ProduitsComponent} from './produits/produits.component';
import {ProduitComponent} from './produit/produit.component';
import {InscriptionComponent} from './inscription/inscription.component';
import {PanierComponent} from './panier/panier.component';
import {RechercheMultiComponent} from './recherche-multi/recherche-multi.component';
import {ResultatRechercheMultiComponent} from './resultat-recherche-multi/resultat-recherche-multi.component'; 

const routes: Routes = [
	{path : 'membres/connexion',
	component : ConnexionComponent
	},

	{path : 'membres/inscription',
	component : InscriptionComponent
	},

	{path : 'produits',
	component : ProduitsComponent
	},

	{path : 'produits/marque/:marque',
	component : ProduitsComponent
	},
	{path : 'produits/modele/:modele',
	component : ProduitComponent
	},
	{path : 'panier/:email',
	component : PanierComponent
	},
	{path : 'panier/ajouter/:modele/:quantite/:email',
	component : PanierComponent
	},
	{path : 'produits/recherche',
	component : RechercheMultiComponent
	},
	{path : 'produits/recherche/resultat/:marque/:prixMin/:prixMax/:genre/:type',
	component : ResultatRechercheMultiComponent
	}


];

@NgModule({
  imports: [RouterModule.forRoot(routes, {onSameUrlNavigation:'reload'})],
  exports: [RouterModule]
})

export class AppRoutingModule {}
