import { Component, OnInit } from '@angular/core';
import { AuthentificationService } from '../authentification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ProduitsService } from '../produits.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { RechercheMultiService } from '../recherche-multi.service';

@Component({
  selector: 'app-recherche-multi',
  templateUrl: './recherche-multi.component.html',
  styleUrls: ['./recherche-multi.component.css']
})

export class RechercheMultiComponent implements OnInit {

  private user: Observable<string>;
  private produits: Object[] = new Array();

  private marques: Object[] = new Array();
  private genres: Object[] = new Array();
  private types: Object[] = new Array();

  private recherche ={"marque":"*","genre":"*","prixMin":"*","prixMax":"*","type":"*"}

  constructor(private route: ActivatedRoute,private rechercheService :RechercheMultiService ,private authService: AuthentificationService, private produitsService: ProduitsService, private router: Router) {
    this.user = this.authService.getUser();
  }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this.produitsService.getProduits().subscribe(produits => {
        this.produits = produits;
        produits.forEach(element => {
          if (this.marques.indexOf(element.marque) == -1) {
            this.marques.push(element.marque);
          }
          if (this.genres.indexOf(element.genre) == -1) {
            this.genres.push(element.genre);
          }
          if (this.types.indexOf(element.type) == -1) {
            this.types.push(element.type);
          }
        });
      });
    });
  }

  
	onSubmit(){
    this.router.navigate(['/produits/recherche/resultat/'+this.recherche.marque+"/"+this.recherche.prixMin+"/"+this.recherche.prixMax+"/"+this.recherche.genre+"/"+this.recherche.type]);
  }

}
