import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RechercheMultiComponent } from './recherche-multi.component';

describe('RechercheMultiComponent', () => {
  let component: RechercheMultiComponent;
  let fixture: ComponentFixture<RechercheMultiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RechercheMultiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RechercheMultiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
