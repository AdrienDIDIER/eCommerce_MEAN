import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';
import { isUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class PanierService {
  private urlBase : string = 'http://localhost:8888/';

  constructor(private http: HttpClient) { }

  getPanierParEmail(email) : Observable<any>{
  	return this.http.get(this.urlBase+'paniers/'+email);
  } 
  
  ajoutProduitPanier(produit, quantite, email) : Observable<any>{
    let produitString = JSON.stringify(produit);
    let modele = produit["modele"];
    let marque = produit["marque"];
    let genre = produit["genre"];
    let prix = produit["prix"];
    let img = produit['img'];
    
    if(quantite == "undefined"){
      var q = 1;
    }
    else{
      q = quantite;
    }

  	return this.http.get(this.urlBase+'paniers/ajouter/'+modele+'/'+marque+'/'+genre+'/'+prix+'/'+img+'/'+q+'/'+email);
  }

  recupInfoProduit(modele, email) : Observable<any>{
    return this.http.get(this.urlBase+'paniers/get/'+modele+'/'+email);
  }

  supprProduit(modele, email) : Observable<any>{
    return this.http.get(this.urlBase+'paniers/supprimer/'+modele+'/'+email);
  }

  updateQuantite(modele, quantite, email) : Observable<any>{
    return this.http.get(this.urlBase+'paniers/modifier/'+modele+'/'+quantite+'/'+email);
  }

  validerPanier(email) : Observable<any>{
    return this.http.get(this.urlBase+'paniers/valider/'+email);
  }

  getNbProduits(email) : Observable<any>{
  	return this.http.get(this.urlBase+'paniers/nombre/'+email);
  }

}
