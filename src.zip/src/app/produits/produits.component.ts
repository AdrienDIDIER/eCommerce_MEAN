import { Component, OnInit } from '@angular/core';
import { AuthentificationService } from '../authentification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ProduitsService } from '../produits.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';



@Component({
	selector: 'app-produits',
	templateUrl: './produits.component.html',
	styleUrls: ['./produits.component.css']
})

export class ProduitsComponent implements OnInit {
	private show: String;
	private user: Observable<string>;
	private produits: Object[] = new Array();

	private produitsE: Object[] = new Array();
	private produitsM: Object[] = new Array();

	constructor(private route: ActivatedRoute, private authService: AuthentificationService, private produitsService: ProduitsService, private router: Router) {
		this.user = this.authService.getUser();
		this.show = "Tout";
	}
	ngOnInit() {
		this.route.params.subscribe((params: Params) => {
			this.produitsService.getProduits().subscribe(produits => {
				this.produits = produits;

				produits.forEach(element => {
					if (element.type == "Electronique") {
						this.produitsE.push(element);
					}
					else {
						this.produitsM.push(element);
					}
				});
			});
		});
	}

	produitParModele(produit) {
		let modele = produit.modele;
		this.router.navigate(['/produits/modele', modele]);
	}

	changeFilter(cat) {
		this.show = cat;
		this.produitsService.getProduits().subscribe(produits => {
			if (cat == "Tout") {
				this.produits = produits;
			}
			else if (cat == 'Electronique') {
				this.produits = this.produitsE;
			}
			else {
				this.produits = this.produitsM;
			}
		});

	}
}

