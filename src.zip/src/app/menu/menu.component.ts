import { Component, OnInit, ɵConsole } from '@angular/core';
import {AuthentificationService } from '../authentification.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { PanierService } from '../panier.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})

export class MenuComponent implements OnInit {
	private user: Observable<string>;
	private nbProduits;

 	constructor(private authService: AuthentificationService, private router : Router, private PanierService : PanierService) {
		 this.user = this.authService.getUser();
 	}

 	ngOnInit() {
 		this.router.navigate(['/produits']);
 	}

 	deconnexion(user){
		this.router.navigate(['/produits']);
		let mail = user.value;
		this.authService.disconnect(mail).subscribe();
		
 	}

	panierParEmail(){
		this.user.subscribe(email =>{
			this.router.navigate(['/panier', email]);
		});
	}

	

}
