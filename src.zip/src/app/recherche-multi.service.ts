import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RechercheMultiService {

  private urlBase : string = 'http://localhost:8888/';

  constructor(private http: HttpClient) { }

  getProduits(recherche) : Observable<any>{
    return this.http.get(this.urlBase+'produits/recherche/'+recherche.marque+"/"+recherche.prixMin+"/"+recherche.prixMax+"/"+recherche.genre+"/"+recherche.type);
  }
}