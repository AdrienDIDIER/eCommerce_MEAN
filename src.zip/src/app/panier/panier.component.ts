import { Component, OnInit, Query } from '@angular/core';
import { AuthentificationService } from '../authentification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Observable } from 'rxjs';
import { Router, NavigationEnd } from '@angular/router';
import { PanierService } from '../panier.service';

@Component({
  selector: 'app-panier',
  templateUrl: './panier.component.html',
  styleUrls: ['./panier.component.css']
})
export class PanierComponent implements OnInit {

  private user: Observable<string>;
  private panier: Object[] = new Array();
  private produit: Object = new Object;
  private prixTotal = 0;

  constructor(private route: ActivatedRoute, private authService: AuthentificationService, private panierService: PanierService, private router: Router) {
    this.user = this.authService.getUser();
  }

  ngOnInit() {
    
    this.route.params.subscribe((params: Params) => {
      this.prixTotal = 0;
      this.prixTotalCalcul(params["email"]);
      if (params["email"] !== undefined && params["modele"] !== undefined) {
        console.log("/panier/ajouter/" + params['modele'] + "/" + params['email']);

        this.panierService.recupInfoProduit(params['modele'], params['email']).subscribe(produit => {
          this.produit = produit[0], this.panierService.ajoutProduitPanier(this.produit, params['quantite'], params["email"]).subscribe(), this.router.navigate(['/produits']);
        });


      }
      else if (params["email"] !== undefined) {
        console.log("/panier/" + params['email']);
        this.panierService.getPanierParEmail(params["email"]).subscribe(panier => { this.panier = panier });
      }
      else {
        console.log("ERREUR");
      }
    });
  }


  supprimerProduit(modele, user) {
    let email = user.value;
    this.panierService.supprProduit(modele, email).subscribe(panier => {
      this.panier = panier, this.panierService.getPanierParEmail(email).subscribe(panier => { this.panier = panier, this.prixTotal=0,this.prixTotalCalcul(email); });
    });
    this.router.navigate(['/panier/' + email]);
  }

  updateQuantite(modele, quantite, user) {
    let email = user.value;
    if(quantite <=0){
      this.panierService.getPanierParEmail(email).subscribe(panier => { this.panier = panier, this.prixTotal=0,this.prixTotalCalcul(email); });
      this.router.navigate(['/panier/' + email]);
    }
    else{
      this.panierService.updateQuantite(modele, quantite, email).subscribe(panier => {
        this.panier = panier, this.panierService.getPanierParEmail(email).subscribe(panier => { this.panier = panier, this.prixTotal=0,this.prixTotalCalcul(email); });
      });
      this.router.navigate(['/panier/' + email]);
    }

  }

  prixTotalCalcul(email) {
    this.panierService.getPanierParEmail(email).subscribe(panier => {
      this.panier = panier;
      panier[0].listeProduits.forEach(element => {
        this.prixTotal += element.prix * element.quantite;
      });
      return this.prixTotal;
    });
  }

  resetPanier(user){
    let email = user.value;
    this.panierService.validerPanier(email).subscribe(panier => {
      this.panier = panier, this.panierService.getPanierParEmail(email).subscribe(panier => { this.panier = panier, this.prixTotal=0,this.prixTotalCalcul(email); });
    });
    this.router.navigate(['/produits']);
    
}

}
