import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Subject,BehaviorSubject} from 'rxjs';
import { Observable } from 'rxjs';

const httpOptions = {
	headers: new HttpHeaders({
		"Access-Control-Allow-Methods": "GET,POST",
		"Access-Control-Allow-Headers": "Content-type",
		"Content-type" : "application/json",
		"Access-Control-Allow-Origin": "*"
	})
};

@Injectable({
  providedIn: 'root'
})
export class AuthentificationService {
    private user:Subject<string> = new BehaviorSubject<string>(undefined);
	private baseURL: string = "http://localhost:8888/";

  	constructor(private http: HttpClient){}

  	getUser(){return this.user;}

  	connect(data: string){this.user.next(data);}

	disconnect(email : string) :Observable<any> {
		console.log(this.baseURL+'membres/deconnexion/'+email);
		try{
			this.user.next(null);
			return this.http.get(this.baseURL+'membres/deconnexion/'+email);
		}
		catch(e){
			console.log("error");
		}
	}

	verificationconnexion(identifiants) : Observable<any> {
    	return this.http.post(this.baseURL+'membres/connexion', JSON.stringify(identifiants), httpOptions);
	}

	verificationInscription(identifiants) : Observable<any> {
		return this.http.post(this.baseURL+'membres/inscription', JSON.stringify(identifiants), httpOptions);
	}

 }
  	
