import { TestBed } from '@angular/core/testing';

import { RechercheMultiService } from './recherche-multi.service';

describe('RechercheMultiService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RechercheMultiService = TestBed.get(RechercheMultiService);
    expect(service).toBeTruthy();
  });
});
