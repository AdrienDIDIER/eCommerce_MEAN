import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResultatRechercheMultiComponent } from './resultat-recherche-multi.component';

describe('ResultatRechercheMultiComponent', () => {
  let component: ResultatRechercheMultiComponent;
  let fixture: ComponentFixture<ResultatRechercheMultiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResultatRechercheMultiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResultatRechercheMultiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
