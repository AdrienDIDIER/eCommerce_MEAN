import { Component, OnInit } from '@angular/core';
import { AuthentificationService } from '../authentification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ProduitsService } from '../produits.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';
import { RechercheMultiService } from '../recherche-multi.service';


@Component({
  selector: 'app-resultat-recherche-multi',
  templateUrl: './resultat-recherche-multi.component.html',
  styleUrls: ['./resultat-recherche-multi.component.css']
})
export class ResultatRechercheMultiComponent implements OnInit {

  private user: Observable<string>;
  private produits: Object[] = new Array();

  constructor(private route: ActivatedRoute, private rechercheService: RechercheMultiService, private authService: AuthentificationService, private produitsService: ProduitsService, private router: Router) {
    this.user = this.authService.getUser();
  }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {

      let recherche = { "marque": params['marque'], "genre": params['genre'], "prixMin": params['prixMin'], "prixMax": params['prixMax'], "type": params['type'] }

      this.rechercheService.getProduits(recherche).subscribe(produits => {
        this.produits = produits
      });
    });
  }

	produitParModele(produit){
		let modele = produit.modele;
		this.router.navigate(['/produits/modele', modele]);
  }
  
}
