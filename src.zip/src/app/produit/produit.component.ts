import { Component, OnInit } from '@angular/core';
import { AuthentificationService } from '../authentification.service';
import { ActivatedRoute, Params } from '@angular/router';
import { ProduitsService } from '../produits.service';
import { ProduitService } from '../produit.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-produit',
  templateUrl: './produit.component.html',
  styleUrls: ['./produit.component.css']
})
export class ProduitComponent implements OnInit {

  private user : Observable<string>;
  private produits: Object[] = new Array;
  private produit: Object;
  private quantite;

  constructor(private route: ActivatedRoute, private authService: AuthentificationService, private produitsService: ProduitsService, private router: Router, private produitService: ProduitService) { 
    this.user = this.authService.getUser();

  }
  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      if(params["modele"] !== undefined){
          this.produitsService.getProduitByModele(params["modele"]).subscribe(produit => {this.produit = produit[0]});
     }
      else{
           this.produitsService.getProduits().subscribe(produits =>{
            this.produits = produits;
           });
      }
    });
  }


	ajouterProduit(modele, user){
    let email = user.value;
    this.router.navigate(['/panier/ajouter/modele/quantite/email', {modele : modele, quantite : this.quantite,email : email}]);
  }
  
  
}
