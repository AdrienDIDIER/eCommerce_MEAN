import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import {AuthentificationService } from './authentification.service';
import { ProduitsService } from './produits.service';


import { AppComponent } from './app.component';
import { ConnexionComponent } from './connexion/connexion.component'
import { ProduitsComponent } from './produits/produits.component';
import { MenuComponent } from './menu/menu.component';
import { InscriptionComponent } from './inscription/inscription.component';
import { ProduitComponent } from './produit/produit.component';
import { PanierComponent } from './panier/panier.component';
import { RechercheMultiComponent } from './recherche-multi/recherche-multi.component';
import { ResultatRechercheMultiComponent } from './resultat-recherche-multi/resultat-recherche-multi.component';

@NgModule({
  declarations: [
    AppComponent,
    ConnexionComponent,
    ProduitsComponent,
    MenuComponent,
    InscriptionComponent,
    ProduitComponent,
    PanierComponent,
    RechercheMultiComponent,
    ResultatRechercheMultiComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [ProduitsService,AuthentificationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
