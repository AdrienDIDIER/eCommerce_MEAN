import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {map} from 'rxjs/operators';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ProduitsService {
  
  private urlBase : string = 'http://localhost:8888/';

  constructor(private http: HttpClient) { }

  getProduits() : Observable<any>{
  	return this.http.get(this.urlBase+'produits');
  }

  getProduitsParMarque(marque) : Observable<any>{
  	return this.http.get(this.urlBase+'produits/marque/'+marque);
  } 
  
  getProduitByModele(modele) : Observable<any>{
  	return this.http.get(this.urlBase+'produits/modele/'+modele);
  }
}
