import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})

export class ProduitService {
  
  private urlBase : string = 'http://localhost:8888/';

  constructor(private http: HttpClient) { }

  ajoutProduitPanier(modele, email) : Observable<any>{
  	return this.http.get(this.urlBase+'paniers/ajouter/'+modele+"/"+email);
  }

}
